import type { Address, OutOfArea, Pharmacy } from "./types";
import { PHARMACIES } from "./catalog";

export const SERVICE_AREA = {
  city: "São Paulo",
  state: "SP",
  allowedCities: ["sao paulo", "são paulo", "sp", "s paulo", "s. paulo"],
  center: { lat: -23.561414, lng: -46.655881 },
  maxRadiusKm: 15,
};

export function normalizeCity(str: string): string {
  return String(str || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function isCityAllowed(city: string): boolean {
  const n = normalizeCity(city);
  if (!n) return false;
  return SERVICE_AREA.allowedCities.some((c) => {
    const cn = normalizeCity(c);
    return n === cn || n.includes(cn) || cn.includes(n);
  });
}

export function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function userRefPoint(addresses: Address[]): { lat: number; lng: number } {
  return { lat: -23.561, lng: -46.656 };
}

export function pharmaciesSorted(addresses: Address[]): (Pharmacy & { distanceKm: number })[] {
  const user = userRefPoint(addresses);
  return PHARMACIES.map((p) => ({
    ...p,
    distanceKm: haversineKm(user, p),
  })).sort((a, b) => a.distanceKm - b.distanceKm);
}

/** SP capital/metro CEPs start with 0 (01000–09999). */
export function isSpMetroCep(cep: string): boolean {
  const d = cep.replace(/\D/g, "");
  if (d.length < 5) return true;
  return d.startsWith("0");
}

export function validateDeliveryArea(address: Address): OutOfArea | null {
  const city = address.city || "";
  const state = (address.state || "").toUpperCase();
  const userLabel =
    [address.street, address.number, city, state].filter(Boolean).join(", ") ||
    city ||
    "Endereço informado";

  if (state && state !== SERVICE_AREA.state && state !== "SAO PAULO") {
    return {
      title: "Ainda não entregamos aí",
      reason: "city",
      userLabel,
      detail: `Recebemos o endereço em ${city || state}. O FarmGo opera somente em ${SERVICE_AREA.city} (${SERVICE_AREA.state}).`,
    };
  }

  if (!isCityAllowed(city)) {
    return {
      title: "Ainda não entregamos aí",
      reason: "city",
      userLabel: city || userLabel,
      detail: `Sua cidade (${city || "informada"}) está fora da área. Entregamos apenas em ${SERVICE_AREA.city}, em percursos de até ${SERVICE_AREA.maxRadiusKm} km.`,
    };
  }

  if (address.cep && !isSpMetroCep(address.cep)) {
    return {
      title: "Endereço longe demais",
      reason: "distance",
      userLabel,
      detail: `O CEP informado fica fora do raio de ${SERVICE_AREA.maxRadiusKm} km do centro de operação (pequena e média distância em ${SERVICE_AREA.city}).`,
    };
  }

  return null;
}

export interface ViaCepResult {
  street: string;
  neighborhood: string;
  city: string;
  state: string;
}

export async function lookupCep(cep: string): Promise<ViaCepResult | null> {
  const clean = cep.replace(/\D/g, "");
  if (clean.length !== 8) return null;
  try {
    const res = await fetch(`https://viacep.com.br/ws/${clean}/json/`);
    if (!res.ok) return null;
    const data = (await res.json()) as {
      erro?: boolean;
      logradouro?: string;
      bairro?: string;
      localidade?: string;
      uf?: string;
    };
    if (data.erro) return null;
    return {
      street: data.logradouro || "",
      neighborhood: data.bairro || "",
      city: data.localidade || "",
      state: data.uf || "",
    };
  } catch {
    return null;
  }
}
