export type IconName =
  | "pill"
  | "tablets"
  | "syringe"
  | "baby"
  | "brain"
  | "sun"
  | "flask"
  | "bottle";

export type CategoryId =
  | "todos"
  | "medicamentos"
  | "infantil"
  | "coracao"
  | "nervoso"
  | "genericos"
  | "beleza";

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "out"
  | "delivered";

export type Role = "customer" | "pharmacy" | "driver" | "guest";

export interface Product {
  id: string;
  name: string;
  shortName: string;
  lab: string;
  price: number;
  price2: number;
  icon: IconName;
  needsRx: boolean;
  time: string;
  desc: string;
  comp: string;
  usage: string;
  contra: string;
  stock: number;
  stockMin: number;
  category: Exclude<CategoryId, "todos">;
  active: boolean;
}

export interface Pharmacy {
  id: string;
  name: string;
  rating: number;
  address: string;
  lat: number;
  lng: number;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  qty: number;
  pharmacyId: string;
  pharmacyName: string;
}

export interface Address {
  id: string;
  label: string;
  cep: string;
  street: string;
  number: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  cpf: string;
  phone: string;
  password: string;
}

export interface Session {
  role: Role;
  userId: string;
  name: string;
  email: string;
  phone?: string;
  cpf?: string;
  vehicle?: string;
  rating?: number;
  storeName?: string;
  pharmacyId?: string;
}

export interface TimelineStep {
  key: "confirmed" | "preparing" | "out" | "delivered";
  label: string;
  at: string | null;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  freight: number;
  discount: number;
  total: number;
  payment: "pix" | "money";
  coupon: string | null;
  address: Address;
  pharmacyName: string;
  pharmacyId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  status: OrderStatus;
  driver: { name: string; rating: number; vehicle: string } | null;
  createdAt: string;
  timeline: TimelineStep[];
  simStartedAt?: string;
}

export interface Prescription {
  id: string;
  name: string;
  status: "validating" | "validated";
  createdAt: string;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  orderId: string | null;
  status?: OrderStatus;
  read: boolean;
  at: string;
}

export interface NotifPrefs {
  orders: boolean;
  promo: boolean;
  push: boolean;
}

export interface Coupon {
  code: string;
  type: "percent" | "fixed" | "frete";
  value: number;
  label: string;
}

export interface DriverAccount {
  logins: string[];
  password: string;
  name: string;
  vehicle: string;
  rating: number;
  id: string;
}

export interface OutOfArea {
  title: string;
  detail: string;
  userLabel: string;
  reason: "city" | "distance";
}
